package com.exemplo.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @GetMapping("/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "world") String name) {
        return String.format("Hello %s!", name);
    }

    @GetMapping("/CPF")
    public String gerarCPF() {
        String cpfGerado = "123.456.789-00"; 
        return cpfGerado;
    }

    @GetMapping("/endereco")
    public String retornarEndereco(
            @RequestParam(value = "nome", defaultValue = "João da Silva") String nome,
            @RequestParam(value = "logradouro", defaultValue = "Rua das Flores, 123") String logradouro) {
        
        return String.format("%s - %s", nome, logradouro);
    }

    // NOVO ENDPOINT DA CALCULADORA:
    @GetMapping("/soma")
    public String somar(
            @RequestParam(value = "a", defaultValue = "0") int a,
            @RequestParam(value = "b", defaultValue = "0") int b) {
        
        int resultado = a + b;
        return String.format("Resultado: %d", resultado);
    }
}
