package com.exemplo.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @GetMapping("/aluno")
    public String retornarAluno() {
        // Retorna o texto formatado exatamente como solicitado
        return "Nome: João da Silva\nCurso: Sistemas de Informação";
    }

    @GetMapping("/professor")
    public String retornarProfessor() {
        // Retorna os dados do professor com a tag <br> para pular a linha no navegador
        return "Professor: Ana Paula Canal<br>Disciplina: Sistemas Operacionais";
    }

    @GetMapping("/calculadora")
    public String calculadora(
            @RequestParam(value = "a", defaultValue = "0") double a,
            @RequestParam(value = "b", defaultValue = "0") double b,
            @RequestParam(value = "operacao", defaultValue = "soma") String operacao) {
        
        double resultado = 0;
        String operacaoFormatada = operacao.toLowerCase(); // Garante que funciona mesmo se digitarem MAIÚSCULO

        switch (operacaoFormatada) {
            case "soma":
                resultado = a + b;
                break;
            case "subtracao":
                resultado = a - b;
                break;
            case "multiplicacao":
                resultado = a * b;
                break;
            case "divisao":
                if (b == 0) {
                    return "Erro: Não é possível dividir por zero!";
                }
                resultado = a / b;
                break;
            default:
                return "Erro: Operação inválida! Escolha entre soma, subtracao, multiplicacao ou divisao.";
        }

        // Usamos %s para o resultado aceitar números com ponto flutuante de forma limpa
        return String.format("Resultado: %s", resultado);
    }

}
